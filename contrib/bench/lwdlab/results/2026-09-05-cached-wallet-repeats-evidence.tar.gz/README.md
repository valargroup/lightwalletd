# Cached wallet measurement evidence

All 35 included comparison runs passed. Raw process counters, Prometheus snapshots,
request/response digests, run setup and wallet completion/resource results are retained.
Wallet database copies, wallet creation logs and wallet secrets are excluded. The
fixture manifest is omitted from wallet result JSON; all numerical completion and
resource records are unchanged. Recorder traces omit wallet addresses and bodies.

The build manifest describes the time the wallet fixture was built; its old
mainnet_sync_complete=false is not the result of these later runs. Per-run results
and cached-evidence-validation.json establish successful completion.

Operator scripts preserve the measured lab paths and finite test plan. Adapt ROOT,
REPO and the SSH alias to reproduce in a separately provisioned private lab. They
are not scripts for public endpoints. remote_cached_run.py imports read/setup
utilities from the older remote_pair_run.py; do not execute the older uncached
entry point for a cached test. Direct timing runs have no RPC trace; separate
recorded runs check response equality. Primary statistics use three paired runs,
not individual wallets as independent experiments.

The supplementary client-host captures contain ps process counters, not arguments.
Use wallet_results CPU values from wait4 for exact per-wallet processor work.
