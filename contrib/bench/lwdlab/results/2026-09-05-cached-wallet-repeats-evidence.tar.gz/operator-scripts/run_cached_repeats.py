#!/usr/bin/env python3
"""Run the predeclared paired plan after the scaling checks pass."""
import json,subprocess,time
from pathlib import Path
ROOT=Path('/tmp/lwd-mainnet-run');STATE=ROOT/'cached-repeats-20260905i.json'
plan=[
 ('content',['ranges','keepalive']),
 ('subtrees',['subtrees-direct','baseline-direct','baseline-direct','subtrees-direct','subtrees-direct','baseline-direct']),
 ('ranges',['ranges-direct','baseline-direct','baseline-direct','ranges-direct','ranges-direct','baseline-direct']),
 ('keepalive',['keepalive-direct','baseline-direct','baseline-direct','keepalive-direct','keepalive-direct','baseline-direct']),
 ('overhead',['subtrees-direct','subtrees','subtrees','subtrees-direct']),
]
state={'status':'waiting_for_scaling','clients':32,'plan':[{'group':g,'variants':v} for g,v in plan],'completed_groups':[]}
def save():
 state['updated_unix']=time.time();p=STATE.with_suffix('.tmp');p.write_text(json.dumps(state,indent=2)+'\n');p.replace(STATE)
save()
try:
 while True:
  s=json.loads((ROOT/'cached-scaling-20260905h.json').read_text())
  if s['status']=='complete':break
  if s['status']=='failed':raise RuntimeError('scaling checks failed')
  time.sleep(2)
 for group,variants in plan:
  root=ROOT/f'cached-{group}-20260905i';state.update(status='running',group=group,root=str(root));save()
  subprocess.run(['python3',str(ROOT/'run_cached_matrix.py'),'--root',str(root),'--prefix',f'cached-i-{group}','--clients','32','--variants',*variants],check=True,timeout=15000)
  subprocess.run(['python3',str(ROOT/'analyze_cached_matrix.py'),str(root)],check=True)
  state['completed_groups'].append(group);save()
 state.update(status='complete');save()
except Exception as error:
 state.update(status='failed',error=repr(error));save();raise
