#!/usr/bin/env python3
"""Sequential bounded comparisons; stop immediately if any run is invalid."""
import argparse,json,subprocess,sys,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--prefix',required=True);p.add_argument('--clients',type=int,required=True);p.add_argument('--variants',nargs='+',required=True);a=p.parse_args()
a.root.mkdir(parents=True,exist_ok=False)
state={'status':'running','clients':a.clients,'completed':[]}
def save():
 state['updated_unix']=time.time();f=a.root/'state.tmp';f.write_text(json.dumps(state,indent=2)+'\n');f.replace(a.root/'state.json')
for i,variant in enumerate(a.variants):
 direct=variant.endswith('-direct');binary=variant.removesuffix('-direct');label=f'{a.prefix}-{i+1}-{variant}';state['current']=label;save()
 cmd=[sys.executable,'/tmp/lwd-mainnet-run/run_cached_wallets.py','--output',str(a.root/label),'--label',label,'--binary',binary,'--clients',str(a.clients),'--timeout','1800']
 if direct:cmd.append('--direct')
 try:
  result=subprocess.run(cmd,timeout=2200)
  run=json.loads((a.root/label/'state.json').read_text())
  if result.returncode or run['status']!='complete':raise RuntimeError(f'{label}: {run}')
  state['completed'].append(run);save()
 except Exception as e:
  state['status']='failed';state['error']=repr(e);save();sys.exit(1)
state['status']='complete';state.pop('current',None);save()
