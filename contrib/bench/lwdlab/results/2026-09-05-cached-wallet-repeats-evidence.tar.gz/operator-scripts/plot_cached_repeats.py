import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
ROOT=Path('/tmp/lwd-mainnet-run');x=json.loads((ROOT/'cached-repeated-results.json').read_text());out=ROOT/'cached-report';out.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.spines.left':False,'axes.spines.bottom':False,'svg.fonttype':'none'})
fig,axes=plt.subplots(1,3,figsize=(15,5.4),gridspec_kw={'wspace':.34})
labels=['PR 9 · Subtree hashes','PR 7 · Range filtering','PR 6 · HTTP connections'];groups=['subtrees','ranges','keepalive']
for ax,(key,title,scale,unit,digits) in zip(axes,[('lwd_cpu_seconds_per_wallet','LWD CPU per wallet',1,'CPU-seconds',2),('allocation_bytes_per_wallet','LWD allocations per wallet',2**20,'MiB allocated over the run',0),('wallet_median_seconds','Wallet completion',1,'seconds',1)]):
 for i,g in enumerate(groups):
  m=x['comparisons'][g]['summaries'][key]
  for j,(v,color) in enumerate([('baseline','#b9c3cf'),('candidate','#247b86')]):
   y=i*1.4+(-.21 if j==0 else .21);s=m[v];n=s['median']/scale
   ax.barh(y,n,height=.34,color=color,zorder=2)
   ax.errorbar(n,y,xerr=[[(s['median']-s['min'])/scale],[(s['max']-s['median'])/scale]],fmt='none',ecolor='#24364a',capsize=3,lw=1,zorder=3)
   ax.text(s['max']/scale+max(1,s['max']/scale)*.045,y,f'{n:,.{digits}f}',va='center',fontsize=10,color='#25344a')
 ax.set_yticks([i*1.4 for i in range(3)],labels if ax==axes[0] else ['']*3)
 ax.invert_yaxis();ax.tick_params(axis='both',length=0,pad=8);ax.set_title(title,loc='left',fontsize=13,fontweight='bold',pad=18);ax.set_xlabel(unit,labelpad=12,color='#506174');ax.grid(axis='x',color='#e6eaef',lw=.7,zorder=0)
 bound=max(x['comparisons'][g]['summaries'][key][v]['max']/scale for g in groups for v in ('baseline','candidate'));ax.set_xlim(0,bound*1.24)
fig.suptitle('32 wallets restoring from mainnet',x=.04,y=.98,ha='left',fontsize=22,fontweight='bold',color='#142b40')
fig.text(.04,.89,'Three paired runs per PR. Bars show medians; whiskers show the observed range. Lower is better.',fontsize=11,color='#506174')
fig.legend(handles=[Patch(color='#b9c3cf',label='Baseline'),Patch(color='#247b86',label='With the PR')],loc='lower left',bbox_to_anchor=(.035,.05),frameon=False,ncol=2)
fig.text(.04,.025,'Direct wallet connections. Allocation totals are not resident memory. Each PR has its own paired baseline.',fontsize=10,color='#506174')
fig.subplots_adjust(left=.18,right=.98,top=.76,bottom=.22)
for suffix in ['png','svg']:fig.savefig(out/('2026-09-05-cached-wallet-repeats.'+suffix),dpi=180,facecolor='white')
