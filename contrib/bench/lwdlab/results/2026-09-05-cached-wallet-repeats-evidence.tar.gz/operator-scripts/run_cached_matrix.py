#!/usr/bin/env python3
"""Sequential bounded comparisons; stop immediately if any run is invalid."""
import argparse,json,subprocess,sys,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--prefix',required=True);p.add_argument('--clients',type=int,required=True);p.add_argument('--variants',nargs='+',required=True);a=p.parse_args()
a.root.mkdir(parents=True,exist_ok=False)
state={'status':'running','clients':a.clients,'completed':[]}
def save():
 state['updated_unix']=time.time();f=a.root/'state.tmp';f.write_text(json.dumps(state,indent=2)+'\n');f.replace(a.root/'state.json')
for i,variant in enumerate(a.variants):
 direct=variant.endswith('-direct');binary=variant.removesuffix('-direct');label=f'{a.prefix}-{i+1}-{variant}';state['current']=label;save()
 cmd=[sys.executable,'/tmp/lwd-mainnet-run/run_cached_wallets.py','--output',str(a.root/label),'--label',label,'--binary',binary,'--clients',str(a.clients),'--timeout','1800']
 if direct:cmd.append('--direct')
 try:
  child=subprocess.Popen(cmd);started=time.monotonic()
  with (a.root/(label+'-client-host.jsonl')).open('w') as capture:
   while True:
    snap=subprocess.run(['ps','-axo','pid=,ppid=,time=,rss=,%cpu=,comm='],capture_output=True,text=True,check=True)
    wallets=[];host_process_percent_cpu=0.0
    for line in snap.stdout.splitlines():
     columns=line.split(None,5)
     if len(columns)!=6:continue
     pid,ppid,cpu_time,rss,pcpu,comm=columns
     host_process_percent_cpu+=float(pcpu)
     if comm.endswith('/lwd_mainnet_wallet'):
      wallets.append({'pid':int(pid),'ppid':int(ppid),'cpu_time':cpu_time,'rss_kib':int(rss),'percent_cpu':float(pcpu)})
    capture.write(json.dumps({'unix_seconds':time.time(),'elapsed_seconds':time.monotonic()-started,'wallets':wallets,'host_sum_process_percent_cpu':host_process_percent_cpu})+'\n');capture.flush()
    code=child.poll()
    if code is not None:break
    if time.monotonic()-started>2200:raise TimeoutError('bounded cached run exceeded2200s')
    time.sleep(1)
  result=subprocess.CompletedProcess(cmd,code)
  run=json.loads((a.root/label/'state.json').read_text())
  if result.returncode or run['status']!='complete':raise RuntimeError(f'{label}: {run}')
  state['completed'].append(run);save()
 except Exception as e:
  state['status']='failed';state['error']=repr(e);save();sys.exit(1)
state['status']='complete';state.pop('current',None);save()
