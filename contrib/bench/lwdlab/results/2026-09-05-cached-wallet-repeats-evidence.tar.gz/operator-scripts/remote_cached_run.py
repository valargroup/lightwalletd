#!/usr/bin/env python3
"""Bounded cached-wallet measurement on the owned lab; never resumes an importer."""
import argparse, hashlib, json, os, re, socket, time
from pathlib import Path
from remote_pair_run import ROOT, TIP_HASH, run, unit, pid, metrics, check_tip
from sample_processes import snapshot

CACHE=Path('/mnt/lwd_mainnet_bench_ff8d/lwd-baseline')
LOCK=ROOT/'cached-measurement.lock'
VERIFY=ROOT/'cache-verified.json'
ALLOWED=('baseline','keepalive','ranges','hex','subtrees','mempool','bundle','subtree-rpc-hash')

def cache_stats():
    return {name:{'bytes':(CACHE/'db/main'/name).stat().st_size,'mtime_ns':(CACHE/'db/main'/name).stat().st_mtime_ns} for name in ('lengths','blocks')}

def preflight():
    for service in ('lwd-bench-import','lwd-bench-cache'):
        assert run('systemctl','show',service,'-p','ActiveState','--value').stdout.strip()=='inactive', f'{service} must be stopped'
    assert not (CACHE/'import.lock').exists(), 'cache writer lock exists'
    imported=json.loads((CACHE/'import.json').read_text())
    assert imported['cache_end']==imported['node_tip']==3470422 and imported['node_tip_hash']==TIP_HASH
    verified=json.loads(VERIFY.read_text())
    assert verified['status']=='complete' and verified['height']==3470422 and verified['records']==3470423 and verified['tip_hash']==TIP_HASH
    assert all(verified[k] for k in ('all_record_checksums_valid','all_height_links_valid','all_tree_sizes_valid'))
    stats=cache_stats()
    for name in stats:
        assert stats[name]=={'bytes':verified[name+'_bytes'],'mtime_ns':verified[name+'_mtime_ns']}, f'{name} changed after verification'
    return verified,stats

def cleanup(label):
    if not LOCK.exists(): return
    assert json.loads(LOCK.read_text())['label']==label, 'another measurement owns the cache'
    for kind in ('sample','record','server'): run('systemctl','stop',unit(label,kind),check=False)
    for kind in ('sample','record','server'):
        state=run('systemctl','show',unit(label,kind),'-p','ActiveState','--value',check=False).stdout.strip()
        assert state not in ('active','activating','deactivating'), f'{kind} did not stop'
    LOCK.unlink()

def start(label,binary,timeout,recorded):
    verified,stats=preflight();state=check_tip()
    binaries=json.loads((ROOT/'binaries.json').read_text())['binaries']
    binaries['subtree-rpc-hash']={'source':'bdc603c9176b468281a551490cff06f34b894a45','sha256':'f015c90a2b2f30f1eac6e452eba7ae6ed847a258649009c86e5483478812a65c'}
    selected=binaries[binary]
    for name,expected in [(binary,selected['sha256']),('lab','c6c9e952de5912ce63cad2c05c8bb68d2863273bd6ef3620fc1fa7fa4ec4e378')]:
        with (ROOT/'bin'/name).open('rb') as f: assert hashlib.file_digest(f,'sha256').hexdigest()==expected
    for port in (19067,19068,19069):
        with socket.socket() as s: assert s.connect_ex(('127.0.0.1',port))!=0, f'port {port} in use'
    with LOCK.open('x') as f: json.dump({'label':label,'started_unix':time.time()},f)
    directory=ROOT/'paired'/label
    try:
        directory.mkdir(parents=True,mode=0o700,exist_ok=False)
        run('systemd-run','--unit='+unit(label,'server'),f'--property=RuntimeMaxSec={timeout+600}','--property=CPUAffinity=0 1','--setenv=GOMAXPROCS=2',str(ROOT/'bin'/binary),'--rpchost','127.0.0.1','--rpcport','18232','--rpcuser','benchmark','--rpcpassword','unused','--no-tls-very-insecure','--grpc-bind-addr','127.0.0.1:19067','--http-bind-addr','127.0.0.1:19069','--data-dir',str(CACHE),'--log-file',str(directory/'server.log'))
        if recorded:
            run('systemd-run','--unit='+unit(label,'record'),f'--property=RuntimeMaxSec={timeout+600}','--property=CPUAffinity=6 7','--setenv=GOMAXPROCS=2',str(ROOT/'bin/lab'),'record','-listen','127.0.0.1:19068','-upstream','127.0.0.1:19067','-output',str(directory/'rpcs.jsonl'))
        for attempt in range(600):
            try:
                metrics(directory,'before');break
            except OSError:
                if attempt==599:raise
                time.sleep(.1)
        # Keep startup/cache-index reading outside the wallet timing window.
        time.sleep(2);metrics(directory,'before')
        pids={'lwd':pid(label,'server'),'node':int(run('systemctl','show','lwd-bench-node','-p','MainPID','--value').stdout)}
        if recorded:pids['recorder']=pid(label,'record')
        assert all(p>0 for p in pids.values())
        affinity={name:run('taskset','-pc',str(p)).stdout.strip() for name,p in pids.items()}
        assert affinity['lwd'].endswith(('0,1','0-1')) and affinity['node'].endswith('2-5')
        if recorded:assert affinity['recorder'].endswith(('6,7','6-7'))
        command=['systemd-run','--unit='+unit(label,'sample'),f'--property=RuntimeMaxSec={timeout+600}','--property=CPUAffinity=6 7','/usr/bin/python3',str(ROOT/'sample_processes.py'),'--output',str(directory/'processes.jsonl'),'--seconds',str(timeout+500)]
        for name,p in pids.items():command.extend(['--process',f'{name}={p}'])
        run(*command)
        assert cache_stats()==stats, 'server startup modified verified cache'
        result={'label':label,'binary':binary,**selected,'cache':'complete','recorded':recorded,'wallet_timeout_seconds':timeout,'node':state,'pids':pids,'start_ticks':{name:snapshot(p)['start_ticks'] for name,p in pids.items()},'affinity':affinity,'setup_completed_unix':time.time(),'cache_stats':stats,'cache_verification':verified}
        (directory/'setup.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
    except BaseException:
        cleanup(label);raise

def finish(label):
    directory=ROOT/'paired'/label;setup=json.loads((directory/'setup.json').read_text())
    try:
        current={'lwd':pid(label,'server'),'node':int(run('systemctl','show','lwd-bench-node','-p','MainPID','--value').stdout)}
        if setup['recorded']:current['recorder']=pid(label,'record')
        assert current==setup['pids'] and all(snapshot(p)['start_ticks']==setup['start_ticks'][name] for name,p in current.items()), 'measured process changed'
        assert run('systemctl','is-active',unit(label,'sample'),check=False).stdout.strip()=='active'
        metrics(directory,'after');(directory/'node-after.json').write_text(json.dumps(check_tip(),indent=2)+'\n')
        (directory/'process-identity-after.json').write_text(json.dumps(current,indent=2)+'\n')
        run('systemctl','kill','--signal=TERM',unit(label,'sample'));time.sleep(.5)
    finally:cleanup(label)
    assert cache_stats()==setup['cache_stats'], 'measurement modified cache'
    preflight()
    print(json.dumps({'label':label,'finished':True,'cache_unchanged':True}))

def main():
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=('preflight','start','finish','cleanup'));parser.add_argument('label',nargs='?',default='');parser.add_argument('--binary',choices=ALLOWED,default='baseline');parser.add_argument('--wallet-timeout',type=int,default=3600);parser.add_argument('--direct',action='store_true');a=parser.parse_args()
    if a.action=='preflight':preflight();print('{"ready":true}');return
    if not re.fullmatch('[a-z0-9-]{1,60}',a.label):parser.error('invalid label')
    if not 300<=a.wallet_timeout<=21600:parser.error('invalid wallet timeout')
    if a.action=='start':start(a.label,a.binary,a.wallet_timeout,not a.direct)
    elif a.action=='finish':finish(a.label)
    else:cleanup(a.label)
if __name__=='__main__':main()
