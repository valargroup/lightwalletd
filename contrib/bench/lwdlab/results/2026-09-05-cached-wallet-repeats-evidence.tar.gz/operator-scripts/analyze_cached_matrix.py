#!/usr/bin/env python3
"""Summarize validated cached wallet batches without inferring capacity."""
import collections,json,math,statistics,sys
from pathlib import Path
root=Path(sys.argv[1]);rows=[]
def prom(p):
 return {line.rsplit(' ',1)[0]:float(line.rsplit(' ',1)[1]) for line in p.read_text().splitlines() if line and not line.startswith('#')}
def pct(v,q):
 v=sorted(v);return v[max(0,math.ceil(len(v)*q)-1)]
for path in sorted(root.glob('*/state.json')):
 state=json.loads(path.read_text())
 if state['status']!='complete':continue
 s=path.parent/'server';setup=json.loads((s/'setup.json').read_text());samples=[json.loads(x) for x in (s/'processes.jsonl').read_text().splitlines()]
 process={}
 for name in setup['pids']:
  series=[r['processes'][name] for r in samples]
  cpu=sum(series[-1][k]-series[0][k] for k in ('user_cpu_seconds','system_cpu_seconds'))
  process[name]={'cpu_seconds':cpu,'cpu_seconds_per_wallet':cpu/state['clients'],'mean_cores':cpu/(samples[-1]['elapsed_seconds']-samples[0]['elapsed_seconds']),'sampled_peak_rss_bytes':max(r['rss_bytes'] for r in series),'storage_read_bytes':series[-1]['io']['read_bytes']-series[0]['io']['read_bytes']}
 before,after=prom(s/'lwd-before.prom'),prom(s/'lwd-after.prom');nb,na=prom(s/'node-before.prom'),prom(s/'node-after.prom')
 rpc=collections.defaultdict(list)
 if state['recorded']:
  for x in (s/'rpcs.jsonl').read_text().splitlines():
   r=json.loads(x);name=r['method'].rsplit('/',1)[1]
   if name=='GetSubtreeRoots':name+=' pool '+str(r['request']['pool'])
   rpc[name].append(r['seconds'])
 row={'label':state['label'],'binary':state['binary'],'clients':state['clients'],'recorded':state['recorded'],'source':setup['source'],'binary_sha256':setup['sha256'],'batch_seconds':state['batch_seconds'],'wallet_elapsed_seconds':state['wallet_elapsed_seconds'],'wallet_median_seconds':statistics.median(state['wallet_elapsed_seconds']),'wallet_p95_seconds':pct(state['wallet_elapsed_seconds'],.95),'process':process,'allocation_bytes_per_wallet':(after['go_memstats_alloc_bytes_total']-before['go_memstats_alloc_bytes_total'])/state['clients'],'mallocs_per_wallet':(after['go_memstats_mallocs_total']-before['go_memstats_mallocs_total'])/state['clients'],'rpc_durations':{k:{'count':len(v),'median_seconds':statistics.median(v),'p95_seconds':pct(v,.95),'sum_seconds':sum(v)} for k,v in rpc.items()},'backend_rpc_deltas':{k:na[k]-nb.get(k,0) for k in na if k.startswith('rpc_requests_total') and na[k]!=nb.get(k,0)}}
 wallet_result=json.loads((path.parent/'wallets/result.json').read_text())
 row['client_host']=wallet_result['client_host']
 row['wallet_process_cpu_seconds']=sum(w['user_cpu_seconds']+w['system_cpu_seconds'] for w in wallet_result['wallet_results'])
 row['wallet_process_mean_cores']=row['wallet_process_cpu_seconds']/row['batch_seconds']
 row['wallet_process_peak_rss_bytes']=max(w['peak_rss_bytes'] for w in wallet_result['wallet_results'])
 rows.append(row)
(root/'analysis.json').write_text(json.dumps({'runs':rows},indent=2)+'\n')
for r in rows:print(r['binary'],'direct' if not r['recorded'] else 'recorded',r['clients'],'walletMedian',round(r['wallet_median_seconds'],2),'batch',round(r['batch_seconds'],2),'LWD CPU/wallet',round(r['process']['lwd']['cpu_seconds_per_wallet'],3),'LWD cores',round(r['process']['lwd']['mean_cores'],3),'allocMiB/wallet',round(r['allocation_bytes_per_wallet']/2**20,2))
