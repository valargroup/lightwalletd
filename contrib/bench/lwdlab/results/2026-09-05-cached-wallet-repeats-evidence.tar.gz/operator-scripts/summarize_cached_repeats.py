#!/usr/bin/env python3
"""Collect validated paired data; preserve per-run variability and applicability."""
import json,statistics,subprocess
from pathlib import Path
ROOT=Path('/tmp/lwd-mainnet-run')
state=json.loads((ROOT/'cached-repeats-20260905i.json').read_text())
assert state['status']=='complete','paired measurements are still pending'
result={'schema':1,'concurrency':32,'primary_transport':'direct SSH tunnel without RPC recorder','comparison_order':['candidate/baseline','baseline/candidate','candidate/baseline'],'comparisons':{},'screening':{},'overhead':[]}
metrics={'wallet_median_seconds':lambda r:r['wallet_median_seconds'],'wallet_p95_seconds':lambda r:r['wallet_p95_seconds'],'batch_seconds':lambda r:r['batch_seconds'],'lwd_cpu_seconds_per_wallet':lambda r:r['process']['lwd']['cpu_seconds_per_wallet'],'node_cpu_seconds_per_wallet':lambda r:r['process']['node']['cpu_seconds_per_wallet'],'allocation_bytes_per_wallet':lambda r:r['allocation_bytes_per_wallet'],'lwd_peak_rss_bytes':lambda r:r['process']['lwd']['sampled_peak_rss_bytes']}
for group,pr in [('subtrees',9),('ranges',7),('keepalive',6)]:
 root=ROOT/f'cached-{group}-20260905i';subprocess.run(['python3',str(ROOT/'analyze_cached_matrix.py'),str(root)],check=True)
 runs=json.loads((root/'analysis.json').read_text())['runs'];assert len(runs)==6 and all(r['clients']==32 and not r['recorded'] for r in runs)
 base=[r for r in runs if r['binary']=='baseline'];cand=[r for r in runs if r['binary']==group];assert len(base)==len(cand)==3
 summaries={}
 for name,get in metrics.items():
  b,c=[get(r) for r in base],[get(r) for r in cand]
  summaries[name]={'baseline':{'median':statistics.median(b),'min':min(b),'max':max(b)},'candidate':{'median':statistics.median(c),'min':min(c),'max':max(c)},'change_percent':100*(statistics.median(c)/statistics.median(b)-1)}
 pairs=[]
 for i in range(0,6,2):
  pair=runs[i:i+2];b=next(r for r in pair if r['binary']=='baseline');c=next(r for r in pair if r['binary']==group)
  pairs.append({'order':[r['binary'] for r in pair],'baseline_label':b['label'],'candidate_label':c['label'],'change_percent':{name:100*(get(c)/get(b)-1) for name,get in metrics.items()}})
 result['comparisons'][group]={'pr':pr,'runs':runs,'summaries':summaries,'pairs':pairs}
for name in ['cached-eight-20260905g','cached-16-20260905h','cached-32-20260905h','cached-content-20260905i','cached-overhead-20260905i']:
 root=ROOT/name;subprocess.run(['python3',str(ROOT/'analyze_cached_matrix.py'),str(root)],check=True);result['screening'][name]=json.loads((root/'analysis.json').read_text())['runs']
# Three candidate recorder-overhead pairs. First recorded/direct pair is adjacent in scaling.
h=result['screening']['cached-32-20260905h'];o=result['screening']['cached-overhead-20260905i'];pairs=[[h[1],h[2]],o[:2],o[2:4]]
for pair in pairs:
 assert len(pair)==2 and all(r['binary']=='subtrees' and r['clients']==32 for r in pair)
 direct=next(r for r in pair if not r['recorded']);recorded=next(r for r in pair if r['recorded'])
 result['overhead'].append({'direct_label':direct['label'],'recorded_label':recorded['label'],'direct_wallet_median_seconds':direct['wallet_median_seconds'],'recorded_wallet_median_seconds':recorded['wallet_median_seconds'],'change_percent':100*(recorded['wallet_median_seconds']/direct['wallet_median_seconds']-1)})
(ROOT/'cached-repeated-results.json').write_text(json.dumps(result,indent=2)+'\n')
for group,r in result['comparisons'].items():
 print(group,{k:round(v['change_percent'],2) for k,v in r['summaries'].items()})
