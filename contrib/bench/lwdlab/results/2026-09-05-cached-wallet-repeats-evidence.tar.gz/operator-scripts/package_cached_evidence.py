import hashlib,io,json,tarfile
from pathlib import Path
ROOT=Path('/tmp/lwd-mainnet-run');REPO=Path('/Users/czstudio/.codex/worktrees/8787/lightwalletd');OUT=ROOT/'cached-report';stem='2026-09-05-cached-wallet-repeats'
x=json.loads((ROOT/'cached-repeated-results.json').read_text());entries={}
def raw(path,name):entries[name]=path.read_bytes()
def js(value,name):entries[name]=(json.dumps(value,indent=2)+'\n').encode()
for group,rows in [(f'cached-{g}-20260905i',c['runs']) for g,c in x['comparisons'].items()]+list(x['screening'].items()):
 for r in rows:
  path=ROOT/group/r['label'];base=group+'/'+r['label'];raw(path/'state.json',base+'/state.json')
  for name in ['setup.json','process-identity-after.json','node-after.json','processes.jsonl','lwd-before.prom','lwd-after.prom','node-before.prom','node-after.prom']+(['rpcs.jsonl'] if r['recorded'] else []):raw(path/'server'/name,base+'/server/'+name)
  w=json.loads((path/'wallets/result.json').read_text());w.pop('fixture');js(w,base+'/wallets/result.json')
  host=path.parent/(r['label']+'-client-host.jsonl')
  if host.exists():raw(host,group+'/'+host.name)
 for name in ['state.json','analysis.json']:raw(ROOT/group/name,group+'/'+name)
for name in ['run_cached_wallets.py','run_cached_matrix.py','run_cached_matrix_v1.py','run_cached_scaling.py','run_cached_repeats.py','remote_cached_run.py','remote_pair_run.py','analyze_cached_matrix.py','summarize_cached_repeats.py','validate_cached_evidence.py','plot_cached_repeats.py','write_cached_report.py','package_cached_evidence.py']:
 raw(ROOT/name,'operator-scripts/'+name)
for name in ['wallet_sessions.py','sample_processes.py']:raw(REPO/'contrib/bench/lwdlab'/name,'operator-scripts/'+name)
for name in ['binaries.json','wallet-build.json','cached-evidence-validation.json','cached-scaling-20260905h.json','cached-repeats-20260905i.json']:
 raw(ROOT/name,'provenance/'+name)
for name in ['cache-verified.json','import.json']:raw(ROOT/'cache-complete-evidence'/name,'provenance/'+name)
raw(ROOT/'checks/nocache-diagnostic-20260905/rpcs.jsonl','reference/rpcs.jsonl')
entries['README.md']=b'''# Cached wallet measurement evidence

All 35 included comparison runs passed. Raw process counters, Prometheus snapshots,
request/response digests, run setup and wallet completion/resource results are retained.
Wallet database copies, wallet creation logs and wallet secrets are excluded. The
fixture manifest is omitted from wallet result JSON; all numerical completion and
resource records are unchanged. Recorder traces omit wallet addresses and bodies.

The build manifest describes the time the wallet fixture was built; its old
mainnet_sync_complete=false is not the result of these later runs. Per-run results
and cached-evidence-validation.json establish successful completion.

Operator scripts preserve the measured lab paths and finite test plan. Adapt ROOT,
REPO and the SSH alias to reproduce in a separately provisioned private lab. They
are not scripts for public endpoints. remote_cached_run.py imports read/setup
utilities from the older remote_pair_run.py; do not execute the older uncached
entry point for a cached test. Direct timing runs have no RPC trace; separate
recorded runs check response equality. Primary statistics use three paired runs,
not individual wallets as independent experiments.

The supplementary client-host captures contain ps process counters, not arguments.
Use wallet_results CPU values from wait4 for exact per-wallet processor work.
'''
archive=OUT/(stem+'-evidence.tar.gz')
with tarfile.open(archive,'w:gz',format=tarfile.PAX_FORMAT) as tar:
 for name,blob in sorted(entries.items()):
  assert not name.endswith(('.db','.sqlite','.sqlite3')) and '..' not in Path(name).parts
  info=tarfile.TarInfo(name);info.size=len(blob);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(blob))
checks={name:hashlib.sha256(blob).hexdigest() for name,blob in entries.items()}
with tarfile.open(archive) as tar:
 assert len(tar.getmembers())==len(entries)
 for member in tar:
  assert member.isfile() and hashlib.sha256(tar.extractfile(member).read()).hexdigest()==checks[member.name]
artifacts={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in OUT.glob(stem+'*') if p.name!=stem+'-manifest.json'}
(OUT/(stem+'-manifest.json')).write_text(json.dumps({'schema':1,'artifacts':artifacts,'archive_members':checks},indent=2)+'\n')
print(json.dumps({'archive_bytes':archive.stat().st_size,'archive_members':len(entries),'all_member_checksums_valid':True}))
