#!/usr/bin/env python3
import json,subprocess,time
from pathlib import Path
root=Path('/tmp/lwd-mainnet-run');status=root/'cached-scaling-20260905h.json'
def save(**kw):status.write_text(json.dumps({**kw,'updated_unix':time.time()},indent=2)+'\n')
try:
 prior=root/'cached-eight-20260905g/state.json'
 while True:
  s=json.loads(prior.read_text())
  if s['status']=='complete':break
  if s['status']!='running':raise RuntimeError('eight-wallet screening failed')
  save(status='waiting_for_eight_wallets');time.sleep(2)
 for clients,variants in [(16,['baseline','subtrees']),(32,['baseline','subtrees','subtrees-direct','baseline-direct'])]:
  path=root/f'cached-{clients}-20260905h';save(status='running',clients=clients,root=str(path))
  subprocess.run(['python3',str(root/'run_cached_matrix.py'),'--root',str(path),'--prefix',f'cached-h-n{clients}','--clients',str(clients),'--variants',*variants],check=True,timeout=10000)
 save(status='complete')
except Exception as e:save(status='failed',error=repr(e));raise
