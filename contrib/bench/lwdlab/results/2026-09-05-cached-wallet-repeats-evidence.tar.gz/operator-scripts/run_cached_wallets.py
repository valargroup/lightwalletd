#!/usr/bin/env python3
"""Run one bounded real-wallet measurement against the verified private cache."""
import argparse, collections, json, shlex, subprocess, sys, time
from pathlib import Path
ROOT=Path('/tmp/lwd-mainnet-run');REPO=Path('/Users/czstudio/.codex/worktrees/8787/lightwalletd');HOST='codex-bright-forge-ff8d';HELPER='/root/lwd-bench/remote_cached_run.py'

def remote(*args):
    result=subprocess.run(['ssh',HOST,shlex.join(['python3',HELPER,*args])],capture_output=True,text=True,timeout=240)
    if result.returncode:raise RuntimeError('remote '+args[0]+': '+result.stderr[-3000:])
    return result
def signature(path):
    rows=[json.loads(line) for line in path.read_text().splitlines()]
    assert rows and all(row['code']=='OK' for row in rows),'RPC errors or cancellations occurred'
    return collections.Counter(json.dumps({key:row.get(key) for key in ('method','request','messages','bytes','code','response_sha256')},sort_keys=True) for row in rows)
def write_state(out,state):
    state['updated_unix']=time.time();temp=out/'state.tmp';temp.write_text(json.dumps(state,indent=2)+'\n');temp.replace(out/'state.json')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);parser.add_argument('--label',required=True);parser.add_argument('--binary',choices=('baseline','keepalive','ranges','hex','subtrees','mempool','bundle','subtree-rpc-hash'),default='baseline');parser.add_argument('--clients',type=int,choices=(1,8,16,32),default=1);parser.add_argument('--timeout',type=int,default=3600);parser.add_argument('--direct',action='store_true');a=parser.parse_args()
    out=a.output.resolve();out.mkdir(parents=True,mode=0o700,exist_ok=False)
    state={'status':'running','label':a.label,'binary':a.binary,'clients':a.clients,'recorded':not a.direct,'cache':'complete','timeout_seconds':a.timeout};write_state(out,state)
    started=False;failure=None;cleanup_errors=[]
    try:
        args=['start',a.label,'--binary',a.binary,'--wallet-timeout',str(a.timeout)]
        if a.direct:args.append('--direct')
        setup=remote(*args);started=True;(out/'setup-command.json').write_text(setup.stdout)
        with (out/'controller.log').open('w') as log:
            subprocess.run([sys.executable,str(REPO/'contrib/bench/lwdlab/wallet_sessions.py'),'run','--wallet-binary',str(ROOT/'vizor/rust/target/release/examples/lwd_mainnet_wallet'),'--fixture-dir',str(ROOT/'fixtures/restore'),'--output',str(out/'wallets'),'--label',a.label,'--clients',str(a.clients),'--expected-tip','3470422','--timeout',str(a.timeout),'--url','http://127.0.0.1:'+('19079' if a.direct else '19078')],check=True,stdout=log,stderr=subprocess.STDOUT,timeout=a.timeout+100)
    except BaseException as error:failure=repr(error)
    finally:
        try:remote('finish' if started else 'cleanup',a.label)
        except Exception as error:
            cleanup_errors.append(repr(error))
            try:remote('cleanup',a.label)
            except Exception as extra:cleanup_errors.append(repr(extra))
        copy=subprocess.run(['scp','-q','-r',f'{HOST}:/root/lwd-bench/paired/{a.label}',str(out/'server')],capture_output=True,text=True,timeout=180)
        if copy.returncode:cleanup_errors.append('evidence copy: '+copy.stderr)
    if failure or cleanup_errors:
        write_state(out,{**state,'status':'failed','error':failure,'cleanup_errors':cleanup_errors});return 1
    try:
        result=json.loads((out/'wallets/result.json').read_text());assert result['all_complete'] and result['completed_clients']==a.clients
        if not a.direct:
            expected=signature(ROOT/'checks/nocache-diagnostic-20260905/rpcs.jsonl');expected=collections.Counter({k:v*a.clients for k,v in expected.items()})
            assert signature(out/'server/rpcs.jsonl')==expected,'request/response signatures changed'
        samples=[json.loads(line) for line in (out/'server/processes.jsonl').read_text().splitlines()]
        assert len(samples)>2 and all('error' not in p for row in samples for p in row['processes'].values()),'process capture errors'
        assert samples[-1]['elapsed_seconds']-samples[0]['elapsed_seconds']>=result['batch_elapsed_seconds']-1,'capture too short'
        assert max(b['elapsed_seconds']-a['elapsed_seconds'] for a,b in zip(samples,samples[1:]))<=5,'capture gap'
        setup=json.loads((out/'server/setup.json').read_text());assert json.loads((out/'server/process-identity-after.json').read_text())==setup['pids']
        for name in setup['pids']:
            assert {(row['processes'][name]['pid'],row['processes'][name]['start_ticks']) for row in samples}=={(setup['pids'][name],setup['start_ticks'][name])},'process identity changed'
        def messages(text):return sum(float(line.rsplit(' ',1)[1]) for line in text.splitlines() if line.startswith('grpc_server_msg_sent_total{') and 'grpc_method="GetBlockRange"' in line)
        assert messages((out/'server/lwd-after.prom').read_text())-messages((out/'server/lwd-before.prom').read_text())==20423*a.clients,'wrong delivered block count'
        cpu={name:sum(samples[-1]['processes'][name][k]-samples[0]['processes'][name][k] for k in ('user_cpu_seconds','system_cpu_seconds')) for name in setup['pids']}
        write_state(out,{**state,'status':'complete','batch_seconds':result['batch_elapsed_seconds'],'wallet_elapsed_seconds':[w['elapsed_seconds'] for w in result['wallet_results']],'process_cpu_seconds':cpu,'all_complete':True,'transcript_checked':not a.direct,'process_samples':len(samples),'cache_verification':setup['cache_verification']})
    except Exception as error:write_state(out,{**state,'status':'validation_failed','error':repr(error)});return 1
    return 0
if __name__=='__main__':sys.exit(main())
