#!/usr/bin/env python3
"""Independently recheck all published cached measurements against their raw evidence."""
import collections,json,math
from pathlib import Path
ROOT=Path('/tmp/lwd-mainnet-run');TIP='000000000073dfbd7bf192181f1f0e060ef3c4f295504ca1c513fa49ce6b3723'
report=json.loads((ROOT/'cached-repeated-results.json').read_text())
def sig(path):
 rows=[json.loads(x) for x in path.read_text().splitlines()];assert all(x['code']=='OK' for x in rows)
 return collections.Counter(json.dumps({k:x.get(k) for k in ('method','request','messages','bytes','code','response_sha256')},sort_keys=True) for x in rows)
def prom(path):
 return {x.rsplit(' ',1)[0]:float(x.rsplit(' ',1)[1]) for x in path.read_text().splitlines() if x and not x.startswith('#')}
expected=sig(ROOT/'checks/nocache-diagnostic-20260905/rpcs.jsonl');runs=[]
for group,c in report['comparisons'].items():runs.extend((ROOT/f'cached-{group}-20260905i'/r['label'],r) for r in c['runs'])
for group,rows in report['screening'].items():runs.extend((ROOT/group/r['label'],r) for r in rows)
assert len({p for p,r in runs})==len(runs)==35
checks=[]
for path,r in runs:
 state=json.loads((path/'state.json').read_text());w=json.loads((path/'wallets/result.json').read_text());server=path/'server';setup=json.loads((server/'setup.json').read_text())
 assert state['status']=='complete' and w['all_complete'] and w['completed_clients']==w['clients']==r['clients']
 assert w['expected_tip']==3470422 and all(x['success'] and x['progress']['is_complete'] and x['progress']['chain_tip_height']==3470422 and not x['timed_out'] for x in w['wallet_results'])
 assert r['source']==setup['source'] and r['binary_sha256']==setup['sha256']
 assert setup['node']['bestblockhash']==json.loads((server/'node-after.json').read_text())['bestblockhash']==TIP
 assert json.loads((server/'process-identity-after.json').read_text())==setup['pids']
 samples=[json.loads(x) for x in (server/'processes.jsonl').read_text().splitlines()]
 span=samples[-1]['elapsed_seconds']-samples[0]['elapsed_seconds'];gap=max(b['elapsed_seconds']-a['elapsed_seconds'] for a,b in zip(samples,samples[1:]));assert span>=w['batch_elapsed_seconds']-1 and gap<=5
 for name,pid in setup['pids'].items():
  assert all('error' not in s['processes'][name] and s['processes'][name]['pid']==pid and s['processes'][name]['start_ticks']==setup['start_ticks'][name] for s in samples)
  cpu=sum(samples[-1]['processes'][name][k]-samples[0]['processes'][name][k] for k in ('user_cpu_seconds','system_cpu_seconds'));assert math.isclose(cpu,r['process'][name]['cpu_seconds'],abs_tol=1e-6)
 before,after=prom(server/'lwd-before.prom'),prom(server/'lwd-after.prom')
 sent=lambda p:sum(v for k,v in p.items() if k.startswith('grpc_server_msg_sent_total{') and 'grpc_method="GetBlockRange"' in k)
 assert sent(after)-sent(before)==20423*w['clients']
 for name in ('lengths','blocks'):
  assert setup['cache_stats'][name]=={'bytes':setup['cache_verification'][name+'_bytes'],'mtime_ns':setup['cache_verification'][name+'_mtime_ns']}
 if r['recorded']:assert sig(server/'rpcs.jsonl')==collections.Counter({k:v*w['clients'] for k,v in expected.items()})
 checks.append({'label':r['label'],'clients':r['clients'],'recorded':r['recorded'],'capture_seconds':span,'max_capture_gap_seconds':gap,'status':'passed'})
result={'status':'passed','runs':len(checks),'completed_wallet_sessions':sum(r['clients'] for r in checks),'recorded_wallet_sessions':sum(r['clients'] for r in checks if r['recorded']),'checks':checks}
(ROOT/'cached-evidence-validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='checks'}))
