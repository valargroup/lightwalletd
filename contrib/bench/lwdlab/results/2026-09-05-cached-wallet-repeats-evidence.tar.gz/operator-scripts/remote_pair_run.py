#!/usr/bin/env python3
"""Bounded process setup for the private mainnet wallet comparison host."""
import argparse,hashlib,json,re,socket,subprocess,time,urllib.request
from pathlib import Path
from sample_processes import snapshot

ROOT=Path('/root/lwd-bench')
TIP_HASH='000000000073dfbd7bf192181f1f0e060ef3c4f295504ca1c513fa49ce6b3723'
BINARIES={'baseline':('d79cd1100575ff909d70e00d5514a4092df94934','0db0f41c36debaeda99bdd58b499338d3d10c4b3ee624c67e3dc47221d6fd818'),'subtree-rpc-hash':('bdc603c9176b468281a551490cff06f34b894a45','f015c90a2b2f30f1eac6e452eba7ae6ed847a258649009c86e5483478812a65c')}

def run(*args,check=True):
 return subprocess.run(args,check=check,capture_output=True,text=True,timeout=150)
def unit(label,kind): return f'lwd-repeat-{label}-{kind}'
def pid(label,kind): return int(run('systemctl','show',unit(label,kind),'-p','MainPID','--value').stdout)
def metrics(directory,phase):
 for name,port in [('lwd',19069),('node',19998)]:
  data=urllib.request.urlopen(f'http://127.0.0.1:{port}/metrics',timeout=10).read()
  (directory/f'{name}-{phase}.prom').write_bytes(data)
def check_tip():
 req=urllib.request.Request('http://127.0.0.1:18232',data=json.dumps({'jsonrpc':'2.0','id':'pair-preflight','method':'getblockchaininfo','params':[]}).encode(),headers={'Content-Type':'application/json'})
 state=json.load(urllib.request.urlopen(req,timeout=10))['result']
 assert state['chain']=='main' and state['blocks']==3470422 and state['bestblockhash']==TIP_HASH
 return state

def cleanup(label):
 for kind in ('sample','record','server'):
  run('systemctl','stop',unit(label,kind),check=False)
 resumed=run('systemctl','start','lwd-bench-import.service',check=False)
 if resumed.returncode==0:
  run('systemctl','stop',unit(label,'resume')+'.timer',check=False)
 else:
  raise RuntimeError('Importer resume failed; recovery timer retained')

def start(label,binary,timeout=4500):
 directory=ROOT/'paired'/label
 directory.mkdir(parents=True,mode=0o700,exist_ok=False)
 state=check_tip()
 for name,expected in [(binary,BINARIES[binary][1]),('lab','c6c9e952de5912ce63cad2c05c8bb68d2863273bd6ef3620fc1fa7fa4ec4e378')]:
  assert hashlib.file_digest((ROOT/'bin'/name).open('rb'),'sha256').hexdigest()==expected
 assert run('systemctl','is-active','lwd-bench-import.service',check=False).stdout.strip()=='active'
 for port in (19067,19068,19069):
  with socket.socket() as s: assert s.connect_ex(('127.0.0.1',port))!=0, f'port {port} in use'
 run('systemd-run','--unit='+unit(label,'resume'),f'--on-active={timeout+900}s','/usr/bin/systemctl','start','lwd-bench-import.service')
 run('systemctl','kill','--kill-whom=main','--signal=USR1','lwd-bench-import.service')
 deadline=time.monotonic()+120
 while run('systemctl','is-active','lwd-bench-import.service',check=False).stdout.strip()=='active':
  assert time.monotonic()<deadline, 'Importer did not checkpoint in time'
  time.sleep(.25)
 assert run('systemctl','show','lwd-bench-import.service','-p','Result','--value').stdout.strip()=='success', 'Importer failed while checkpointing'
 assert not Path('/mnt/lwd_mainnet_bench_ff8d/lwd-baseline/import.lock').exists(), 'Importer retained its lock'
 time.sleep(20) # Let already submitted import RPCs finish before measuring.
 run('systemd-run','--unit='+unit(label,'server'),f'--property=RuntimeMaxSec={timeout+600}','--property=CPUAffinity=0 1','--setenv=GOMAXPROCS=2',str(ROOT/'bin'/binary),'--nocache','--rpchost','127.0.0.1','--rpcport','18232','--rpcuser','benchmark','--rpcpassword','unused','--no-tls-very-insecure','--grpc-bind-addr','127.0.0.1:19067','--http-bind-addr','127.0.0.1:19069','--data-dir','/mnt/lwd_mainnet_bench_ff8d/repeat-'+label,'--log-file',str(directory/'server.log'))
 run('systemd-run','--unit='+unit(label,'record'),f'--property=RuntimeMaxSec={timeout+600}','--property=CPUAffinity=6 7','--setenv=GOMAXPROCS=2',str(ROOT/'bin/lab'),'record','-listen','127.0.0.1:19068','-upstream','127.0.0.1:19067','-output',str(directory/'rpcs.jsonl'))
 for attempt in range(100):
  try:
   metrics(directory,'before'); break
  except OSError:
   if attempt==99: raise
   time.sleep(.1)
 pids={'lwd':pid(label,'server'),'recorder':pid(label,'record'),'node':int(run('systemctl','show','lwd-bench-node.service','-p','MainPID','--value').stdout)}
 assert all(p>0 for p in pids.values())
 affinity={name:run('taskset','-pc',str(p)).stdout.strip() for name,p in pids.items()}
 assert affinity['lwd'].endswith('0,1') or affinity['lwd'].endswith('0-1')
 assert affinity['node'].endswith('2-5')
 assert affinity['recorder'].endswith('6,7') or affinity['recorder'].endswith('6-7')
 command=['systemd-run','--unit='+unit(label,'sample'),f'--property=RuntimeMaxSec={timeout+600}','--property=CPUAffinity=6 7','/usr/bin/python3',str(ROOT/'sample_processes.py'),'--output',str(directory/'processes.jsonl'),'--seconds',str(timeout+500)]
 for name,p in pids.items(): command.extend(['--process',f'{name}={p}'])
 run(*command)
 record={'label':label,'binary':binary,'source':BINARIES[binary][0],'sha256':BINARIES[binary][1],'cache':'nocache','wallet_timeout_seconds':timeout,'node':state,'pids':pids,'start_ticks':{name:snapshot(p)["start_ticks"] for name,p in pids.items()},'affinity':affinity,'setup_completed_unix':time.time(),'import_settle_seconds':20}
 (directory/'setup.json').write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps(record))

def finish(label):
 directory=ROOT/'paired'/label
 try:
  setup=json.loads((directory/'setup.json').read_text())
  current={'lwd':pid(label,'server'),'recorder':pid(label,'record'),'node':int(run('systemctl','show','lwd-bench-node.service','-p','MainPID','--value').stdout)}
  assert current==setup['pids'], 'A measured process restarted'
  assert all(snapshot(p)['start_ticks']==setup['start_ticks'][name] for name,p in current.items()), 'Process identity changed'
  assert run('systemctl','is-active',unit(label,'sample'),check=False).stdout.strip()=='active', 'Resource sampler stopped before wallet completed'
  (directory/'process-identity-after.json').write_text(json.dumps(current,indent=2)+'\n')
  metrics(directory,'after')
  (directory/'node-after.json').write_text(json.dumps(check_tip(),indent=2)+'\n')
  run('systemctl','kill','--signal=TERM',unit(label,'sample'))
  time.sleep(.5)
 finally:
  cleanup(label)
 print(json.dumps({'label':label,'finished':True}))

def main():
 p=argparse.ArgumentParser();p.add_argument('action',choices=['start','finish','cleanup']);p.add_argument('label');p.add_argument('--binary',choices=BINARIES,default='baseline');p.add_argument('--wallet-timeout',type=int,default=4500);a=p.parse_args()
 if not re.fullmatch('[a-z0-9-]{1,60}',a.label): p.error('invalid label')
 if not 4500<=a.wallet_timeout<=43200: p.error('timeout outside allowed bounds')
 if a.action=='start': start(a.label,a.binary,a.wallet_timeout)
 elif a.action=='finish': finish(a.label)
 else: cleanup(a.label)
if __name__=='__main__': main()
