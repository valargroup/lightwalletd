import json,statistics
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path('/Users/czstudio/.codex/worktrees/8787/lightwalletd/contrib/bench/lwdlab/results')
runs=json.loads(Path('/tmp/lwd-mainnet-run/paired-20260905b/analysis.json').read_text())['runs']
groups=[[r for r in runs if r['phase']=='paired' and r['binary']==name] for name in ('baseline','subtree-rpc-hash')]
fig,axes=plt.subplots(3,1,figsize=(10,8.2))
fig.subplots_adjust(left=.20,right=.95,top=.84,bottom=.10,hspace=.68)
fig.text(.05,.95,'Wallet restore without a block cache',fontsize=21,weight='bold',color='#172A3A')
fig.text(.05,.90,'Real mainnet data • One wallet • Three paired repeats • Median and observed range',fontsize=11,color='#546575')
metrics=[('Wallet completion','Minutes',lambda r:r['wallet_seconds']/60,'min'),('lightwalletd CPU per wallet','CPU-seconds',lambda r:r['process']['lwd']['cpu_seconds'],'s'),('Zakura backend CPU per wallet','CPU-seconds',lambda r:r['process']['node']['cpu_seconds'],'s')]
for ax,(title,xlabel,fn,unit) in zip(axes,metrics):
 values=[[fn(r) for r in g] for g in groups];med=[statistics.median(x) for x in values];limit=max(max(v) for v in values)*1.28
 ax.set_title(title,loc='left',pad=12,fontsize=13,weight='bold',color='#172A3A')
 ax.barh([1,0],med,color=['#667788','#1976BC'],height=.48,zorder=3)
 ax.errorbar(med,[1,0],xerr=[[m-min(v) for m,v in zip(med,values)],[max(v)-m for m,v in zip(med,values)]],fmt='none',ecolor='#182C3B',capsize=4,zorder=4)
 for y,m in zip([1,0],med): ax.text(m+limit*.018,y,f'{m:,.1f} {unit}',va='center',fontsize=12,weight='bold',color='#172A3A')
 ax.set_yticks([1,0],['Baseline','Direct hash lookup']);ax.tick_params(axis='y',length=0,labelsize=11)
 ax.set_xlim(0,limit);ax.set_xlabel(xlabel,fontsize=10,color='#546575');ax.set_axisbelow(True);ax.grid(axis='x',color='#E6ECF1')
 for spine in ax.spines.values(): spine.set_visible(False)
 ax.tick_params(axis='x',colors='#546575')
fig.text(.05,.025,'Cache misses only. These results do not establish cached-server performance or concurrent-wallet capacity.',fontsize=10,color='#546575')
for ext in ('png','svg'):fig.savefig(root/f'2026-09-05-mainnet-wallet-repeats.{ext}',dpi=170,facecolor='white')
print(matplotlib.__version__)
