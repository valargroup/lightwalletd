import collections,json,re,statistics,sys
from pathlib import Path
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/tmp/lwd-mainnet-run/paired-20260905b')
state=json.loads((root/'state.json').read_text())
expected=None;out=[]
def prom(path):
 return {line.rsplit(' ',1)[0]:float(line.rsplit(' ',1)[1]) for line in path.read_text().splitlines() if line and not line.startswith('#')}
for item in state['completed']:
 p=root/item['label']; r=json.loads((p/'wallets/result.json').read_text()); s=p/'server';setup=json.loads((s/'setup.json').read_text())
 assert r['all_complete'] and r['expected_tip']==3470422 and r['clients']==1
 assert setup['node']['bestblockhash']=='000000000073dfbd7bf192181f1f0e060ef3c4f295504ca1c513fa49ce6b3723'
 assert json.loads((s/'node-after.json').read_text())['bestblockhash']==setup['node']['bestblockhash']
 assert json.loads((s/'process-identity-after.json').read_text())==setup['pids']
 samples=[json.loads(x) for x in (s/'processes.jsonl').read_text().splitlines()]
 assert samples[-1]['elapsed_seconds']-samples[0]['elapsed_seconds']>=r['batch_elapsed_seconds']-1
 assert max(b['elapsed_seconds']-a['elapsed_seconds'] for a,b in zip(samples,samples[1:]))<5
 process={}
 for name in setup['pids']:
  v=[x['processes'][name] for x in samples]
  assert all(x['pid']==setup['pids'][name] and x['start_ticks']==setup['start_ticks'][name] for x in v)
  process[name]={'cpu_seconds':v[-1]['user_cpu_seconds']+v[-1]['system_cpu_seconds']-v[0]['user_cpu_seconds']-v[0]['system_cpu_seconds'],'peak_rss_bytes':max(x['rss_bytes'] for x in v)}
 before=prom(s/'lwd-before.prom');after=prom(s/'lwd-after.prom'); nb=prom(s/'node-before.prom');na=prom(s/'node-after.prom')
 rpc={k:na[k]-nb.get(k,0) for k in na if k.startswith('rpc_requests_total') and na[k]!=nb.get(k,0)}
 traces=[json.loads(x) for x in (s/'rpcs.jsonl').read_text().splitlines()]
 if item['recorded']:
  sig=collections.Counter(json.dumps({k:x.get(k) for k in ['method','request','messages','bytes','code','response_sha256']},sort_keys=True) for x in traces)
  if expected is None:expected=sig
  assert sig==expected and all(x['code']=='OK' for x in traces)
 row={**item,'process':process,'capture_seconds':samples[-1]['elapsed_seconds']-samples[0]['elapsed_seconds'],'allocation_bytes':after['go_memstats_alloc_bytes_total']-before['go_memstats_alloc_bytes_total'],'mallocs':after['go_memstats_mallocs_total']-before['go_memstats_mallocs_total'],'backend_rpc_deltas':rpc,'subtree_seconds':{str(x['request']['pool']):x['seconds'] for x in traces if x['method'].endswith('/GetSubtreeRoots')}}
 out.append(row)
result={'source_directory':str(root),'runs':out,'validated_complete_runs':len(out)}
(root/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
for x in out:
 print(x['label'],round(x['wallet_seconds'],3),'lwdCPU',round(x['process']['lwd']['cpu_seconds'],2),'nodeCPU',round(x['process']['node']['cpu_seconds'],2),'allocGiB',round(x['allocation_bytes']/2**30,3),'RSSMiB',round(x['process']['lwd']['peak_rss_bytes']/2**20,2),'RPC',x['backend_rpc_deltas'])
