#!/usr/bin/env python3
"""Run a bounded, alternating no-cache wallet comparison on the owned lab."""
import collections,json,shlex,subprocess,sys,time
from pathlib import Path
ROOT=Path('/tmp/lwd-mainnet-run')
OUT=ROOT/'paired-20260905b'
HOST='codex-bright-forge-ff8d'
HELPER='/root/lwd-bench/remote_pair_run.py'
REPO=Path('/Users/czstudio/.codex/worktrees/8787/lightwalletd')

def remote(*args):
 return subprocess.run(['ssh',HOST,shlex.join(['python3',HELPER,*args])],check=True,capture_output=True,text=True,timeout=240)
def signature(path):
 rows=[json.loads(x) for x in path.read_text().splitlines()]
 assert rows and all(r['code']=='OK' for r in rows)
 return collections.Counter(json.dumps({k:r.get(k) for k in ['method','request','messages','bytes','code','response_sha256']},sort_keys=True) for r in rows)
def state(value):
 value['updated_unix']=time.time()
 temp=OUT/'state.tmp';temp.write_text(json.dumps(value,indent=2)+'\n');temp.replace(OUT/'state.json')

def main():
 OUT.mkdir(mode=0o700,exist_ok=False)
 expected=signature(ROOT/'checks/nocache-diagnostic-20260905/rpcs.jsonl')
 plan=[]
 for pair,order in enumerate([['subtree-rpc-hash','baseline'],['baseline','subtree-rpc-hash'],['subtree-rpc-hash','baseline']],1):
  for binary in order:
   short='hash' if binary!='baseline' else 'base'
   plan.append({'label':f'20260905b-p{pair}-{short}','phase':'paired','pair':pair,'binary':binary,'recorded':True})
 for pair,order in enumerate([[False,True],[True,False],[False,True]],1):
  for recorded in order:
   plan.append({'label':f'20260905b-o{pair}-'+('record' if recorded else 'direct'),'phase':'recorder-overhead','pair':pair,'binary':'subtree-rpc-hash','recorded':recorded})
 (OUT/'plan.json').write_text(json.dumps({'clients':1,'wallet_timeout_seconds':4500,'runs':plan},indent=2)+'\n')
 completed=[]
 for item in plan:
  label=item['label']; directory=OUT/label;directory.mkdir(mode=0o700)
  status={'status':'running','current':item,'completed':completed}
  state(status)
  started=False
  try:
   setup=remote('start',label,'--binary',item['binary']);started=True
   (directory/'setup-command.json').write_text(setup.stdout)
   endpoint='http://127.0.0.1:'+('19078' if item['recorded'] else '19079')
   with (directory/'controller.log').open('w') as output:
    subprocess.run([sys.executable,str(REPO/'contrib/bench/lwdlab/wallet_sessions.py'),'run','--wallet-binary',str(ROOT/'vizor/rust/target/release/examples/lwd_mainnet_wallet'),'--fixture-dir',str(ROOT/'fixtures/restore'),'--output',str(directory/'wallets'),'--label',label,'--clients','1','--expected-tip','3470422','--timeout','4500','--url',endpoint],check=True,stdout=output,stderr=subprocess.STDOUT,timeout=4600)
  finally:
   try:
    if started: remote('finish',label)
    else: remote('cleanup',label)
   except Exception:
    remote('cleanup',label)
    raise
  subprocess.run(['scp','-q','-r',f'{HOST}:/root/lwd-bench/paired/{label}',str(directory/'server')],check=True,timeout=120)
  result=json.loads((directory/'wallets/result.json').read_text())
  assert result['all_complete'] and result['completed_clients']==1
  if item['recorded']: assert signature(directory/'server/rpcs.jsonl')==expected, 'RPC contents changed'
  samples=[json.loads(x) for x in (directory/'server/processes.jsonl').read_text().splitlines()]
  assert len(samples)>2 and all('error' not in p for row in samples for p in row['processes'].values()), 'Process capture failed'
  assert samples[-1]['elapsed_seconds']-samples[0]['elapsed_seconds']>=result['batch_elapsed_seconds']-1, 'Resource capture did not cover full wallet run'
  assert max(b['elapsed_seconds']-a['elapsed_seconds'] for a,b in zip(samples,samples[1:]))<=5, 'Gap in resource capture'
  setup=json.loads((directory/'server/setup.json').read_text())
  assert json.loads((directory/'server/process-identity-after.json').read_text())==setup['pids'], 'Measured process restarted'
  before=(directory/'server/lwd-before.prom').read_text();after=(directory/'server/lwd-after.prom').read_text()
  def range_messages(text):
   return sum(float(line.rsplit(' ',1)[1]) for line in text.splitlines() if line.startswith('grpc_server_msg_sent_total{') and 'grpc_method="GetBlockRange"' in line)
  assert range_messages(after)-range_messages(before)==20423, 'Wrong block count in server metrics'
  completed.append({**item,'wallet_seconds':result['batch_elapsed_seconds'],'all_complete':True,'transcript_checked':item['recorded'],'process_samples':len(samples)})
  state({'status':'running','current':None,'completed':completed})
  print(json.dumps(completed[-1]),flush=True)
 state({'status':'complete','completed':completed})

if __name__=='__main__':
 try: main()
 except BaseException as error:
  if OUT.exists():
   previous=json.loads((OUT/'state.json').read_text()) if (OUT/'state.json').exists() else {}
   state({**previous,'status':'failed','error':repr(error)})
  raise
