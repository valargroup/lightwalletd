"""Publish only allowlisted counters, response digests, and reproducibility scripts."""
import hashlib,io,json,tarfile
from pathlib import Path
ROOT=Path('/tmp/lwd-mainnet-run');RUN=ROOT/'single-wallet-20260905j';REPO=Path('/Users/czstudio/.codex/worktrees/8787/lightwalletd');OUT=REPO/'contrib/bench/lwdlab/results';stem='2026-09-05-single-wallet-cache'
data=json.loads((RUN/'analysis.json').read_text());entries={}
def raw(path,name):entries[name]=path.read_bytes()
def js(value,name):entries[name]=(json.dumps(value,indent=2)+'\n').encode()
for label in sorted({r['label'] for r in data['runs']}):
 root=RUN/label;s=root/'server'
 for name in ('setup.json','process-identity-after.json','node-after.json','processes.jsonl'):
  raw(s/name,label+'/server/'+name)
 for phase in ('cold','warm'):
  for name in ('before.json','after.json','lwd-before.prom','lwd-after.prom','node-before.prom','node-after.prom'):
   raw(s/phase/name,label+'/server/'+phase+'/'+name)
  if (s/phase/'rpcs.jsonl').exists():raw(s/phase/'rpcs.jsonl',label+'/server/'+phase+'/rpcs.jsonl')
  w=json.loads((root/phase/'wallets/result.json').read_text());w.pop('fixture');js(w,label+'/'+phase+'/wallet-result.json')
 raw(root/'results.json',label+'/results.json')
for name in ('run.py','checkpoint.py','analyze.py','plot.py','report.py','package.py','launch.py'):
 raw(RUN/name,'operator-scripts/single-wallet/'+name)
for name in ('remote_cached_run.py','remote_pair_run.py','run_cached_wallets.py'):
 raw(ROOT/name,'operator-scripts/'+name)
for name in ('wallet_sessions.py','sample_processes.py'):
 raw(REPO/'contrib/bench/lwdlab'/name,'operator-scripts/'+name)
for name in ('binaries.json','wallet-build.json'):
 raw(ROOT/name,'provenance/'+name)
for name in ('cache-verified.json','import.json'):
 raw(ROOT/'cache-complete-evidence'/name,'provenance/'+name)
for name in ('state.json','cleanup.json'):raw(RUN/name,'provenance/'+name)
raw(ROOT/'checks/nocache-diagnostic-20260905/rpcs.jsonl','reference/rpcs.jsonl')
entries['README.md']=b'''# Single-wallet cache comparison evidence

Six direct server runs each served a cold-process wallet and a second fresh
wallet on the same process. Two more runs recorded both phases for response
verification. All 16 wallet sessions are included. Headline statistics use only
the 12 direct sessions, grouped as three paired repeats per condition.

Phase Prometheus snapshots retain allocation and RPC counters. Phase JSON and
continuous process samples retain CPU, identity, memory and I/O counters.
Recorded phases retain privacy-filtered request metadata and response digests.
Wallet results omit the fixture manifest. No wallet databases, creation logs,
private keys, seeds or operator credentials are included.

Scripts preserve the exact owned-lab paths and finite plan. Adapt ROOT, REPO
and SSH alias for a separately provisioned private lab. These are not general
public-endpoint load scripts. remote_cached_run imports utilities from the old
remote_pair_run module; do not run that older uncached entry point. The launch
wrapper restores the temporary update controls after execution. A bounded
systemd timer provided independent restoration if the local controller failed.

The old build manifest describes fixture creation, not sync completion. The
phase wallet results establish completion at the pinned tip for this experiment.
'''
archive=OUT/(stem+'-evidence.tar.gz')
with tarfile.open(archive,'w:gz',format=tarfile.PAX_FORMAT) as tar:
 for name,blob in sorted(entries.items()):
  assert not name.endswith(('.db','.sqlite','.sqlite3')) and '..' not in Path(name).parts
  info=tarfile.TarInfo(name);info.size=len(blob);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(blob))
checks={name:hashlib.sha256(blob).hexdigest() for name,blob in entries.items()}
with tarfile.open(archive) as tar:
 assert len(tar.getmembers())==len(entries)
 for member in tar:assert member.isfile() and hashlib.sha256(tar.extractfile(member).read()).hexdigest()==checks[member.name]
artifacts={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in OUT.glob(stem+'*') if p.name!=stem+'-manifest.json'}
(OUT/(stem+'-manifest.json')).write_text(json.dumps({'schema':1,'artifacts':artifacts,'archive_members':checks},indent=2)+'\n')
print(json.dumps({'archive_bytes':archive.stat().st_size,'archive_members':len(entries),'all_member_checksums_valid':True}))
