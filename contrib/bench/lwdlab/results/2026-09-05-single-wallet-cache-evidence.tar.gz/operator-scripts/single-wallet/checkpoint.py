#!/usr/bin/env python3
"""Capture phase boundaries without restarting the measured lab processes."""
import hashlib,json,re,sys,time
from remote_cached_run import ROOT,LOCK,preflight,cache_stats,check_tip,metrics,pid,run
from sample_processes import snapshot
label,phase,edge=sys.argv[1:]
assert re.fullmatch('[a-z0-9-]{1,60}',label) and phase in ('cold','warm') and edge in ('before','after')
assert json.loads(LOCK.read_text())['label']==label
root=ROOT/'paired'/label
setup=json.loads((root/'setup.json').read_text())
preflight();check_tip()
assert cache_stats()==setup['cache_stats']
assert pid(label,'server')==setup['pids']['lwd']
assert int(run('systemctl','show','lwd-bench-node','-p','MainPID','--value').stdout)==setup['pids']['node']
processes={name:snapshot(p) for name,p in setup['pids'].items()}
assert all(p['start_ticks']==setup['start_ticks'][name] for name,p in processes.items())
with open('/proc/'+str(setup['pids']['node'])+'/exe','rb') as f:
 assert hashlib.file_digest(f,'sha256').hexdigest()=='f37369563be71ecf050418d8ede477b37087d834b280337385e946757e30408c'
directory=root/phase;directory.mkdir(exist_ok=True)
metrics(directory,edge)
record={'unix_seconds':time.time(),'processes':{name:snapshot(p) for name,p in setup['pids'].items()},'rpc_offset':(root/'rpcs.jsonl').stat().st_size if setup['recorded'] else None}
with (directory/(edge+'.json')).open('x') as f:json.dump(record,f,indent=2)
print(json.dumps({'phase':phase,'edge':edge,'verified':True}))
