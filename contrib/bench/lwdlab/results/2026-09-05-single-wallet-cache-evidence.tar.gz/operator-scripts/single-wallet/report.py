import json,statistics
from pathlib import Path
ROOT=Path('/tmp/lwd-mainnet-run/single-wallet-20260905j');data=json.loads((ROOT/'analysis.json').read_text())
OUT=Path('/Users/czstudio/.codex/worktrees/8787/lightwalletd/contrib/bench/lwdlab/results');stem='2026-09-05-single-wallet-cache'
s=data['summary'];w=s['warm'];c=s['cold']
def pair(phase,metric,scale=1,digits=2):
 d=s[phase][metric];return f"{d['baseline_median']/scale:.{digits}f} → {d['pr9_median']/scale:.{digits}f} ({d['change_percent']:+.1f}%)"
lines=[
 '# Sequential wallet syncs',
 '',
 f"**PR 9 saves server work when wallets arrive one at a time.** For a fresh wallet arriving after one prior sync, median LWD CPU fell from **{w['lwd_cpu_seconds']['baseline_median']:.2f} to {w['lwd_cpu_seconds']['pr9_median']:.2f} CPU-seconds ({-w['lwd_cpu_seconds']['change_percent']:.1f}% less)**. This repeated across three baseline/PR 9 pairs with a complete mainnet disk cache. No simultaneous wallet cohort was needed.",
 '',
 f"For the first wallet after restart, LWD CPU was **{c['lwd_cpu_seconds']['baseline_median']:.2f} → {c['lwd_cpu_seconds']['pr9_median']:.2f} CPU-seconds**. That wallet fills the new hash map. Its next fresh copy can reuse those hashes.",
 '',
 f'![First and next wallet CPU, allocations and sync time]({stem}.png)',
 '',
 '## Results',
 '',
 'Medians of three paired repeats per condition. Allocations are cumulative bytes allocated during serving, not retained RAM. Wallet time includes client scanning and networking.',
 '',
 '| Server state | LWD CPU per wallet | LWD allocated bytes | Wallet sync time |',
 '| --- | ---: | ---: | ---: |',
 f"| First wallet after restart | {pair('cold','lwd_cpu_seconds')} CPU-s | {pair('cold','allocated_bytes',1e6,0)} MB | {pair('cold','wallet_seconds')} s |",
 f"| Next fresh wallet, same process | {pair('warm','lwd_cpu_seconds')} CPU-s | {pair('warm','allocated_bytes',1e6,0)} MB | {pair('warm','wallet_seconds')} s |",
 '',
 f"On this hardware, the warm case avoided **{w['lwd_cpu_seconds']['baseline_median']-w['lwd_cpu_seconds']['pr9_median']:.2f} CPU-seconds of LWD work per fresh sync**. A provider can use this to understand the cost of repeated wallet bootstraps. The production percentage still depends on hardware, wallet behavior, history size, and how much traffic is fresh syncs versus other requests. It is not a measurement of total production CPU or maximum server capacity.",
 '',
 'Wallet completion stayed close to the baseline. These results support a reduction in server work; they do not establish a noticeable speedup for a lone wallet.',
 '',
 f"The absolute LWD saving was **{w['lwd_cpu_seconds']['baseline_median']-w['lwd_cpu_seconds']['pr9_median']:.2f} CPU-seconds per next wallet**, compared with **1.26 CPU-seconds per wallet** in the earlier 32-wallet comparison on the same server hardware. This supports the conclusion that the saving does not require simultaneous wallet arrivals.",
 '',
 '## What ran',
 '',
 'Each server process served two sequential syncs from separate copies of the same untouched disposable Vizor wallet database. The first sync filled any on-demand server caches; the second started with no saved wallet sync progress. LWD stayed running between them. Warming with one wallet was sufficient because the second requested the same complete root lists.',
 '',
 'Both versions used the previously verified full disk cache: **3,470,423 compact-block records**, about **30.8 GB**. “After restart” means an empty process-local hash map, not an empty disk cache. We did not drop the operating system page cache. Server startup and its index read were outside the measurement windows.',
 '',
 'The actual wallet sync core restored birthday **3,450,000** through frozen mainnet height **3,470,422**. Each wallet requested **1,899 subtree roots** (1,128 Sapling, 769 Orchard, two Ironwood) and **20,423 blocks** in ten 2,000-block ranges plus one 423-block range. These requests came from the wallet. No handcrafted RPC workload or public endpoint was used.',
 '',
 'The six primary process runs were baseline/PR 9, PR 9/baseline, baseline/PR 9. Each had a first and next wallet: **12 measured syncs**, all without the recorder. Two additional server runs, one per version, recorded both phases for **four response-equivalence checks**. Those recorded times are excluded from the headline medians.',
 '',
 '## Every primary pair',
 '',
 '| Pair | Wallet | LWD CPU, baseline → PR 9 | Allocations, baseline → PR 9 | Sync time, baseline → PR 9 |',
 '| --- | --- | ---: | ---: | ---: |',
]
for i in range(3):
 for phase in ('cold','warm'):
  rows=[r for r in data['runs'] if int(r['label'].split('-')[2]) in (2*i+1,2*i+2) and r['phase']==phase]
  b=next(r for r in rows if r['binary']=='baseline');p=next(r for r in rows if r['binary']=='subtrees')
  lines.append(f"| {i+1} | {'First' if phase=='cold' else 'Next'} | {b['process_cpu_seconds']['lwd']:.2f} → {p['process_cpu_seconds']['lwd']:.2f} CPU-s | {b['allocated_bytes']/1e6:.0f} → {p['allocated_bytes']/1e6:.0f} MB | {b['wallet_seconds']:.2f} → {p['wallet_seconds']:.2f} s |")
lines.extend([
 '',
 '## Validation and limits',
 '',
 'All **16 wallets completed** at the expected tip. Every phase delivered 20,423 blocks and 1,899 roots. All four recorded phases matched the prior reference exactly for RPC requests, response message counts, byte counts and response digests. LWD and node process identities remained unchanged within each run. Phase CPU and allocation deltas were independently recomputed from retained snapshots. The verified cache file sizes and modification times remained unchanged.',
 '',
 'LWD was pinned to two logical CPUs with `GOMAXPROCS=2`; the node used four other CPUs. The real wallet client ran alone among benchmark wallets on the same Mac used in the previous report, through an SSH tunnel. It still shares that Mac with other applications. Phase CPU counters include the small interval around launching and finishing the wallet; OS accounting has 10 ms resolution. Wallet elapsed time comes from the wallet process, excluding server startup.',
 '',
 f"For the next-wallet condition, node CPU was {pair('warm','node_cpu_seconds')} CPU-s, and wallet client CPU was {pair('warm','client_cpu_seconds')} CPU-s. The structured results retain these alongside LWD counters so the server saving is not confused with wallet scanning work.",
 '',
 'The node served frozen real mainnet state. These tests do not measure live chain advancement, a reorg, funded transaction retrieval, spending, or routine sync by a wallet that already holds its subtree metadata. The existing cache tests cover reorg invalidation; this experiment measures restart and reuse behavior.',
 '',
 '## Revisions and evidence',
 '',
 '- Baseline: `d79cd1100575ff909d70e00d5514a4092df94934`.',
 '- PR 9: `c6ca3d123c3a07dff0c41cf6e91f1660e7e6e7c8`.',
 '- Backend: Zakura `1.3.1+g5f1e12367935`, executable SHA-256 `f37369563be71ecf050418d8ede477b37087d834b280337385e946757e30408c`.',
 '- Mainnet tip hash: `000000000073dfbd7bf192181f1f0e060ef3c4f295504ca1c513fa49ce6b3723`.',
 '- Wallet executable SHA-256: `bc02379bf56e8ac2fd494c8bb9f6660bce90ad77220e05077cb462d76ef0def1`.',
 f'- [Structured results]({stem}.json), [raw evidence and operator scripts]({stem}-evidence.tar.gz), [SHA-256 manifest]({stem}-manifest.json). Wallet databases and secrets are excluded.',
 '- [Previous 32-wallet comparison](2026-09-05-cached-wallet-repeats.md).',
 '',
])
(OUT/(stem+'.md')).write_text('\n'.join(lines))
(OUT/(stem+'.json')).write_text(json.dumps(data,indent=2)+'\n')
