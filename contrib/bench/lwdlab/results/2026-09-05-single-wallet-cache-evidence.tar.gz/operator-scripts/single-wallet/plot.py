import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
ROOT=Path('/tmp/lwd-mainnet-run/single-wallet-20260905j');data=json.loads((ROOT/'analysis.json').read_text())
OUT=Path('/Users/czstudio/.codex/worktrees/8787/lightwalletd/contrib/bench/lwdlab/results');stem='2026-09-05-single-wallet-cache'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'svg.hashsalt':stem})
fig,axes=plt.subplots(1,3,figsize=(14,5.4));colors=['#738294','#087f6e']
for ax,(metric,title,scale,unit) in zip(axes,[('lwd_cpu_seconds','LWD CPU',1,'CPU-s'),('allocated_bytes','Cumulative allocations',1e6,'MB'),('wallet_seconds','Wallet sync time',1,'s')]):
 maxval=max(max(data['summary'][phase][metric][key])/scale for phase in ('cold','warm') for key in ('baseline_values','pr9_values'))
 for y,phase in [(1,'cold'),(0,'warm')]:
  d=data['summary'][phase][metric]
  for offset,color,prefix in [(.17,colors[0],'baseline'),(-.17,colors[1],'pr9')]:
   v=d[prefix+'_median']/scale;values=[x/scale for x in d[prefix+'_values']]
   ax.barh(y+offset,v,height=.27,color=color,zorder=2)
   ax.plot([min(values),max(values)],[y+offset]*2,color='#202c3c',linewidth=1.2,zorder=3)
   ax.scatter(values,[y+offset]*3,s=13,facecolors='white',edgecolors='#202c3c',linewidths=.6,zorder=4)
   ax.text(max(values)+maxval*.035,y+offset,f'{v:.2f}' if scale==1 else f'{v:.0f}',va='center',fontweight='bold',fontsize=10)
 ax.set_title(title,loc='left',fontweight='bold',pad=16)
 ax.set_xlim(0,maxval*1.22);ax.set_ylim(-.5,1.5);ax.set_xlabel(unit)
 ax.set_yticks([1,0],['First wallet\nafter restart','Next fresh\nwallet'] if ax is axes[0] else ['',''])
 ax.grid(axis='x',color='#dfe4e9',linewidth=.7,zorder=0);ax.set_axisbelow(True)
 for side in ('top','right','left'):ax.spines[side].set_visible(False)
 ax.tick_params(axis='y',length=0);ax.spines['bottom'].set_color('#b8c2cc')
fig.suptitle('PR 9: sequential wallet syncs',x=.08,y=.98,ha='left',fontsize=20,fontweight='bold')
fig.text(.08,.90,'One actual Vizor wallet at a time · complete mainnet disk cache · three paired repeats',fontsize=11,color='#495869')
fig.legend(handles=[Patch(color=colors[0],label='Baseline'),Patch(color=colors[1],label='PR 9')],loc='lower left',bbox_to_anchor=(.073,.015),ncol=2,frameon=False)
fig.text(.38,.045,'Bars show medians. Dots show all three runs. Lower is better.',fontsize=10,color='#495869')
fig.subplots_adjust(left=.12,right=.98,top=.77,bottom=.2,wspace=.22)
fig.savefig(OUT/(stem+'.png'),dpi=160,facecolor='white')
fig.savefig(OUT/(stem+'.svg'),facecolor='white',metadata={'Date':None})
