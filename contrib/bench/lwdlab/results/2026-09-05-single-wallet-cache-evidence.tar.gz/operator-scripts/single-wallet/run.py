#!/usr/bin/env python3
"""Three alternating single-wallet pairs; preserve each process for its warm phase."""
import collections,json,shlex,subprocess,sys,time
from pathlib import Path
ROOT=Path('/tmp/lwd-mainnet-run');OUT=ROOT/'single-wallet-20260905j';HOST='codex-bright-forge-ff8d'
sys.path.insert(0,str(ROOT))
from run_cached_wallets import remote,signature
REPO=Path('/Users/czstudio/.codex/worktrees/8787/lightwalletd')
plan=['baseline','subtrees','subtrees','baseline','baseline','subtrees','baseline','subtrees']
state={'status':'running','plan':plan,'primary_runs':6,'validation_runs':2,'completed':[],'phases':['cold','warm'],'clients_per_phase':1,'cold_definition':'new LWD process with full disk cache retained; no OS cache drop','warm_definition':'same LWD process after one complete wallet; fresh untouched wallet DB copy'}
def save():
 state['updated_unix']=time.time();p=OUT/'state.tmp';p.write_text(json.dumps(state,indent=2)+'\n');p.replace(OUT/'state.json')
def checkpoint(label,phase,edge):
 subprocess.run(['ssh',HOST,shlex.join(['python3','/root/lwd-bench/single-wallet-checkpoint.py',label,phase,edge])],check=True,timeout=60,stdout=subprocess.DEVNULL)
def prom(path):
 return {l.rsplit(' ',1)[0]:float(l.rsplit(' ',1)[1]) for l in path.read_text().splitlines() if l and not l.startswith('#')}
def messages(values):
 return sum(v for k,v in values.items() if k.startswith('grpc_server_msg_sent_total{') and 'grpc_method="GetBlockRange"' in k)
save()
try:
 for index,binary in enumerate(plan):
  recorded=index>=6;label=f'single-j-{index+1}-{binary}';out=OUT/label;out.mkdir(mode=0o700)
  state.update(current=label,phase='starting');save();started=False
  try:
   args=['start',label,'--binary',binary,'--wallet-timeout','900']
   if not recorded:args.append('--direct')
   (out/'setup-command.json').write_text(remote(*args).stdout);started=True
   for phase in ('cold','warm'):
    state['phase']=phase;save()
    checkpoint(label,phase,'before')
    with (out/(phase+'.log')).open('w') as log:
     subprocess.run([sys.executable,str(REPO/'contrib/bench/lwdlab/wallet_sessions.py'),'run','--wallet-binary',str(ROOT/'vizor/rust/target/release/examples/lwd_mainnet_wallet'),'--fixture-dir',str(ROOT/'fixtures/restore'),'--output',str(out/phase/'wallets'),'--label',label+'-'+phase,'--clients','1','--expected-tip','3470422','--timeout','600','--url','http://127.0.0.1:'+('19078' if recorded else '19079')],check=True,stdout=log,stderr=subprocess.STDOUT,timeout=630)
    checkpoint(label,phase,'after')
    time.sleep(2)
  finally:
   remote('finish' if started else 'cleanup',label)
   subprocess.run(['scp','-q','-r',f'{HOST}:/root/lwd-bench/paired/{label}',str(out/'server')],check=True,timeout=180)
  setup=json.loads((out/'server/setup.json').read_text());samples=[json.loads(l) for l in (out/'server/processes.jsonl').read_text().splitlines()]
  assert all('error' not in p for row in samples for p in row['processes'].values())
  assert max(b['elapsed_seconds']-a['elapsed_seconds'] for a,b in zip(samples,samples[1:]))<5
  if recorded:
   expected=signature(ROOT/'checks/nocache-diagnostic-20260905/rpcs.jsonl')
   assert signature(out/'server/rpcs.jsonl')==collections.Counter({k:v*2 for k,v in expected.items()})
  rows=[]
  for phase in ('cold','warm'):
   s=out/'server'/phase;before,after=[json.loads((s/(e+'.json')).read_text()) for e in ('before','after')]
   b,a=[prom(s/('lwd-'+e+'.prom')) for e in ('before','after')]
   nb,na=[prom(s/('node-'+e+'.prom')) for e in ('before','after')]
   result=json.loads((out/phase/'wallets/result.json').read_text());assert result['all_complete'] and result['completed_clients']==1
   assert messages(a)-messages(b)==20423
   for name in setup['pids']:
    assert all((v['processes'][name]['pid'],v['processes'][name]['start_ticks'])==(setup['pids'][name],setup['start_ticks'][name]) for v in (before,after))
   rpc=[]
   if recorded:
    data=(out/'server/rpcs.jsonl').read_bytes()[before['rpc_offset']:after['rpc_offset']]
    (s/'rpcs.jsonl').write_bytes(data);assert signature(s/'rpcs.jsonl')==expected
    rpc=[json.loads(l) for l in data.splitlines()]
   row={'label':label,'binary':binary,'phase':phase,'recorded':recorded,'source':setup['source'],'wallet_seconds':result['wallet_results'][0]['elapsed_seconds'],'client_cpu_seconds':sum(result['wallet_results'][0][k] for k in ('user_cpu_seconds','system_cpu_seconds')),'process_cpu_seconds':{name:sum(after['processes'][name][k]-before['processes'][name][k] for k in ('user_cpu_seconds','system_cpu_seconds')) for name in setup['pids']},'allocated_bytes':a['go_memstats_alloc_bytes_total']-b['go_memstats_alloc_bytes_total'],'mallocs':a['go_memstats_mallocs_total']-b['go_memstats_mallocs_total'],'blocks_delivered':20423,'backend_rpc_deltas':{k:na[k]-nb.get(k,0) for k in na if k.startswith('rpc_requests_total') and na[k]!=nb.get(k,0)},'measurement_window_seconds':after['unix_seconds']-before['unix_seconds'],'subtree_streams':[{'pool':r['request']['pool'],'seconds':r['seconds'],'messages':r['messages']} for r in rpc if r['method'].endswith('/GetSubtreeRoots')]}
   rows.append(row);print(json.dumps(row),flush=True)
  (out/'results.json').write_text(json.dumps(rows,indent=2)+'\n');state['completed'].extend(rows);save()
 state.update(status='complete',phase='done');save()
except BaseException as e:
 state.update(status='failed',error=repr(e));save();raise
