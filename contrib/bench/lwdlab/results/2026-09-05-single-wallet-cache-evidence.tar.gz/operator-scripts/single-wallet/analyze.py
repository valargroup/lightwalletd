"""Recompute every phase from retained counters and validate the fixed experiment."""
import collections,json,statistics,sys
from pathlib import Path
ROOT=Path('/tmp/lwd-mainnet-run');OUT=ROOT/'single-wallet-20260905j'
sys.path.insert(0,str(ROOT))
from run_cached_wallets import signature
state=json.loads((OUT/'state.json').read_text());assert state['status']=='complete'
assert len(state['completed'])==16 and len({r['label'] for r in state['completed']})==8
expected=signature(ROOT/'checks/nocache-diagnostic-20260905/rpcs.jsonl')
def prom(path):
 return {l.rsplit(' ',1)[0]:float(l.rsplit(' ',1)[1]) for l in path.read_text().splitlines() if l and not l.startswith('#')}
for row in state['completed']:
 run=OUT/row['label'];s=run/'server';phase=s/row['phase'];setup=json.loads((s/'setup.json').read_text())
 assert setup['source']=={'baseline':'d79cd1100575ff909d70e00d5514a4092df94934','subtrees':'c6ca3d123c3a07dff0c41cf6e91f1660e7e6e7c8'}[row['binary']]
 assert setup['cache_verification']['height']==3470422 and setup['cache_verification']['records']==3470423
 assert json.loads((s/'process-identity-after.json').read_text())==setup['pids']
 bounds={edge:json.loads((phase/(edge+'.json')).read_text()) for edge in ('before','after')}
 samples=[json.loads(l) for l in (s/'processes.jsonl').read_text().splitlines()]
 assert samples[0]['unix_seconds']<=bounds['before']['unix_seconds'] and samples[-1]['unix_seconds']>=bounds['after']['unix_seconds']
 assert max(b['elapsed_seconds']-a['elapsed_seconds'] for a,b in zip(samples,samples[1:]))<5
 for name,pid in setup['pids'].items():
  assert all((r['processes'][name]['pid'],r['processes'][name]['start_ticks'])==(pid,setup['start_ticks'][name]) for r in samples)
  measured=sum(bounds['after']['processes'][name][k]-bounds['before']['processes'][name][k] for k in ('user_cpu_seconds','system_cpu_seconds'))
  assert abs(measured-row['process_cpu_seconds'][name])<1e-9
 before,after=[prom(phase/('lwd-'+edge+'.prom')) for edge in ('before','after')]
 assert row['allocated_bytes']==after['go_memstats_alloc_bytes_total']-before['go_memstats_alloc_bytes_total']
 assert row['mallocs']==after['go_memstats_mallocs_total']-before['go_memstats_mallocs_total']
 def count(p,method):return sum(v for k,v in p.items() if k.startswith('grpc_server_msg_sent_total{') and ('grpc_method="'+method+'"') in k)
 assert count(after,'GetBlockRange')-count(before,'GetBlockRange')==20423
 assert count(after,'GetSubtreeRoots')-count(before,'GetSubtreeRoots')==1899
 w=json.loads((run/row['phase']/'wallets/result.json').read_text());assert w['all_complete'] and w['completed_clients']==1 and w['wallet_results'][0]['success']
 assert row['wallet_seconds']==w['wallet_results'][0]['elapsed_seconds']
 if row['recorded']:assert signature(phase/'rpcs.jsonl')==expected
primary=[r for r in state['completed'] if not r['recorded']]
metrics={'lwd_cpu_seconds':lambda r:r['process_cpu_seconds']['lwd'],'allocated_bytes':lambda r:r['allocated_bytes'],'wallet_seconds':lambda r:r['wallet_seconds'],'node_cpu_seconds':lambda r:r['process_cpu_seconds']['node'],'client_cpu_seconds':lambda r:r['client_cpu_seconds']}
summary={}
for phase in ('cold','warm'):
 summary[phase]={}
 for name,get in metrics.items():
  group={binary:[get(r) for r in primary if r['phase']==phase and r['binary']==binary] for binary in ('baseline','subtrees')}
  assert all(len(v)==3 for v in group.values())
  b,c=[statistics.median(group[k]) for k in ('baseline','subtrees')]
  summary[phase][name]={'baseline_median':b,'pr9_median':c,'change_percent':100*(c/b-1),'baseline_values':group['baseline'],'pr9_values':group['subtrees']}
result={'schema':1,'method':{k:v for k,v in state.items() if k not in ('completed','current','phase','updated_unix')},'summary':summary,'runs':state['completed'],'validation':{'all_16_wallets_complete':True,'all_phase_counters_recomputed':True,'all_process_identities_unchanged':True,'blocks_per_wallet':20423,'subtree_roots_per_wallet':1899,'recorded_wallets_matching_exact_reference':4,'primary_wallets_without_recorder':12}}
(OUT/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
for phase,metrics in summary.items():
 print(phase)
 for name,r in metrics.items():print(name,round(r['baseline_median'],4),round(r['pr9_median'],4),round(r['change_percent'],2))
