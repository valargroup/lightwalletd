import subprocess,sys
try:
 result=subprocess.run([sys.executable,'/tmp/lwd-mainnet-run/single-wallet-20260905j/run.py'])
finally:
 subprocess.run(['ssh','codex-bright-forge-ff8d','python3 /root/lwd-bench/single-wallet-restore.py'],check=True)
 subprocess.run(['ssh','codex-bright-forge-ff8d','systemctl stop lwd-single-wallet-restore.timer'],check=True)
sys.exit(result.returncode)
