# Single-wallet cache comparison evidence

Six direct server runs each served a cold-process wallet and a second fresh
wallet on the same process. Two more runs recorded both phases for response
verification. All 16 wallet sessions are included. Headline statistics use only
the 12 direct sessions, grouped as three paired repeats per condition.

Phase Prometheus snapshots retain allocation and RPC counters. Phase JSON and
continuous process samples retain CPU, identity, memory and I/O counters.
Recorded phases retain privacy-filtered request metadata and response digests.
Wallet results omit the fixture manifest. No wallet databases, creation logs,
private keys, seeds or operator credentials are included.

Scripts preserve the exact owned-lab paths and finite plan. Adapt ROOT, REPO
and SSH alias for a separately provisioned private lab. These are not general
public-endpoint load scripts. remote_cached_run imports utilities from the old
remote_pair_run module; do not run that older uncached entry point. The launch
wrapper restores the temporary update controls after execution. A bounded
systemd timer provided independent restoration if the local controller failed.

The old build manifest describes fixture creation, not sync completion. The
phase wallet results establish completion at the pinned tip for this experiment.
